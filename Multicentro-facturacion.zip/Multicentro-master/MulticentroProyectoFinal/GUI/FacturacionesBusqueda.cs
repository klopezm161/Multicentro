﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace MulticentroProyectoFinal
{
    public partial class FacturacionesBusquesa : Form
    {
        private DataGridView dgvFacturacionBusqueda;

        public FacturacionesBusquesa()
        {
            InitializeComponent();
        }

        public string GetIdFactura()
        {
            return txtNumFacturaFacturacionesBusqueda.Text;
        }


        public DataGridView GetDataView()
        {
            return dgvFacturacionBusqueda;
        }

        private void BtnSalirFacturacionesBusqueda_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnMenuPrincipalFacturacionesBusqueda_Click(object sender, EventArgs e)
        {
            MenuPrincipal menuPrincipalPrograma = new MenuPrincipal();
            menuPrincipalPrograma.Show();
            this.Dispose();
        }

        private void FacturacionesBusquesa_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void txtNumFacturaFacturacionesBusqueda_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAceptarFacturacionesBusqueda_Click(object sender, EventArgs e)
        {
            Facturacion.FacturacionBusquedaBD facturacion= new Facturacion.FacturacionBusquedaBD();
            facturacion.BuscarPorCodigo(GetIdFactura(), GetDataView());
        }
    }
}
