﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulticentroProyectoFinal
{
    /// <summary>
    /// Interfaz para borrar elementos de la base de datos
    /// </summary>
   public interface IBorrarElementoBD
    {
        void Borrar();
    }
}
