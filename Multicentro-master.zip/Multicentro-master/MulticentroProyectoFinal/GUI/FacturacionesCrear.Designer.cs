﻿namespace MulticentroProyectoFinal
{
    partial class FacturarCrear
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnAceptarFacturarCrear = new System.Windows.Forms.Button();
            this.btnMenuPrincipalEnFacturarCrear = new System.Windows.Forms.Button();
            this.txtFechaEmisionFacturarCrear = new System.Windows.Forms.TextBox();
            this.txtNumFacturaFacturarCrear = new System.Windows.Forms.TextBox();
            this.txtNombreClienteFacturarCrear = new System.Windows.Forms.TextBox();
            this.CBoxServicioFacturarCrear = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "FACTURA NUEVA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(273, 79);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Multicentro S.A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(273, 109);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Cédula Jurídica";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 160);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Fecha emisión:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 200);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(166, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Número factura:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(14, 240);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(163, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Nombre cliente:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(14, 280);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 25);
            this.label7.TabIndex = 6;
            this.label7.Text = "Servicio:";
            // 
            // btnAceptarFacturarCrear
            // 
            this.btnAceptarFacturarCrear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptarFacturarCrear.Location = new System.Drawing.Point(358, 400);
            this.btnAceptarFacturarCrear.Margin = new System.Windows.Forms.Padding(5);
            this.btnAceptarFacturarCrear.Name = "btnAceptarFacturarCrear";
            this.btnAceptarFacturarCrear.Size = new System.Drawing.Size(145, 28);
            this.btnAceptarFacturarCrear.TabIndex = 7;
            this.btnAceptarFacturarCrear.Text = "Aceptar";
            this.btnAceptarFacturarCrear.UseVisualStyleBackColor = true;
            this.btnAceptarFacturarCrear.Click += new System.EventHandler(this.btnAceptarFacturarCrear_Click);
            // 
            // btnMenuPrincipalEnFacturarCrear
            // 
            this.btnMenuPrincipalEnFacturarCrear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuPrincipalEnFacturarCrear.Location = new System.Drawing.Point(14, 400);
            this.btnMenuPrincipalEnFacturarCrear.Margin = new System.Windows.Forms.Padding(5);
            this.btnMenuPrincipalEnFacturarCrear.Name = "btnMenuPrincipalEnFacturarCrear";
            this.btnMenuPrincipalEnFacturarCrear.Size = new System.Drawing.Size(145, 28);
            this.btnMenuPrincipalEnFacturarCrear.TabIndex = 8;
            this.btnMenuPrincipalEnFacturarCrear.Text = "Menú Principal";
            this.btnMenuPrincipalEnFacturarCrear.UseVisualStyleBackColor = true;
            this.btnMenuPrincipalEnFacturarCrear.Click += new System.EventHandler(this.BtnMenuPrincipalEnFacturarCrear_Click);
            // 
            // txtFechaEmisionFacturarCrear
            // 
            this.txtFechaEmisionFacturarCrear.Location = new System.Drawing.Point(150, 160);
            this.txtFechaEmisionFacturarCrear.Name = "txtFechaEmisionFacturarCrear";
            this.txtFechaEmisionFacturarCrear.Size = new System.Drawing.Size(353, 30);
            this.txtFechaEmisionFacturarCrear.TabIndex = 10;
            // 
            // txtNumFacturaFacturarCrear
            // 
            this.txtNumFacturaFacturarCrear.Location = new System.Drawing.Point(150, 200);
            this.txtNumFacturaFacturarCrear.Name = "txtNumFacturaFacturarCrear";
            this.txtNumFacturaFacturarCrear.Size = new System.Drawing.Size(353, 30);
            this.txtNumFacturaFacturarCrear.TabIndex = 11;
            // 
            // txtNombreClienteFacturarCrear
            // 
            this.txtNombreClienteFacturarCrear.Location = new System.Drawing.Point(150, 240);
            this.txtNombreClienteFacturarCrear.Name = "txtNombreClienteFacturarCrear";
            this.txtNombreClienteFacturarCrear.Size = new System.Drawing.Size(353, 30);
            this.txtNombreClienteFacturarCrear.TabIndex = 12;
            // 
            // CBoxServicioFacturarCrear
            // 
            this.CBoxServicioFacturarCrear.FormattingEnabled = true;
            this.CBoxServicioFacturarCrear.Location = new System.Drawing.Point(150, 280);
            this.CBoxServicioFacturarCrear.Name = "CBoxServicioFacturarCrear";
            this.CBoxServicioFacturarCrear.Size = new System.Drawing.Size(353, 33);
            this.CBoxServicioFacturarCrear.TabIndex = 13;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 454);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(485, 270);
            this.dataGridView1.TabIndex = 14;
            // 
            // FacturarCrear
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(539, 736);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.CBoxServicioFacturarCrear);
            this.Controls.Add(this.txtNombreClienteFacturarCrear);
            this.Controls.Add(this.txtNumFacturaFacturarCrear);
            this.Controls.Add(this.txtFechaEmisionFacturarCrear);
            this.Controls.Add(this.btnMenuPrincipalEnFacturarCrear);
            this.Controls.Add(this.btnAceptarFacturarCrear);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "FacturarCrear";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FacturarCrear";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FacturarCrear_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnAceptarFacturarCrear;
        private System.Windows.Forms.Button btnMenuPrincipalEnFacturarCrear;
        private System.Windows.Forms.TextBox txtFechaEmisionFacturarCrear;
        private System.Windows.Forms.TextBox txtNumFacturaFacturarCrear;
        private System.Windows.Forms.TextBox txtNombreClienteFacturarCrear;
        private System.Windows.Forms.ComboBox CBoxServicioFacturarCrear;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}