﻿namespace MulticentroProyectoFinal
{
    partial class ServiciosActualizacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProveedor = new System.Windows.Forms.Label();
            this.lblTipoA = new System.Windows.Forms.Label();
            this.lblCantidadA = new System.Windows.Forms.Label();
            this.lblPrecioA = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.lblNombreA = new System.Windows.Forms.Label();
            this.txtNombreServiciosActualizacion = new System.Windows.Forms.TextBox();
            this.txtPrecioServiciosActualizacion = new System.Windows.Forms.TextBox();
            this.txtCantidadServiciosActualizacion = new System.Windows.Forms.TextBox();
            this.btnAceptarServiciosActualizacion = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.CBoxProveedorServiciosActualizacion = new System.Windows.Forms.ComboBox();
            this.CBoxMarcaServiciosActualizacion = new System.Windows.Forms.ComboBox();
            this.CBoxTipoServiciosActualizacion = new System.Windows.Forms.ComboBox();
            this.btnMenuPrincipalEnServiciosActualizacion = new System.Windows.Forms.Button();
            this.dGVActualizacionServicio = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBuscarServiciosActualizacion = new System.Windows.Forms.Button();
            this.TxtCodAActualizarActualizacionServicios = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dGVActualizacionServicio)).BeginInit();
            this.SuspendLayout();
            // 
            // lblProveedor
            // 
            this.lblProveedor.AutoSize = true;
            this.lblProveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProveedor.Location = new System.Drawing.Point(14, 360);
            this.lblProveedor.Name = "lblProveedor";
            this.lblProveedor.Size = new System.Drawing.Size(95, 20);
            this.lblProveedor.TabIndex = 11;
            this.lblProveedor.Text = "Proveedor:";
            // 
            // lblTipoA
            // 
            this.lblTipoA.AutoSize = true;
            this.lblTipoA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoA.Location = new System.Drawing.Point(14, 280);
            this.lblTipoA.Name = "lblTipoA";
            this.lblTipoA.Size = new System.Drawing.Size(48, 20);
            this.lblTipoA.TabIndex = 10;
            this.lblTipoA.Text = "Tipo:";
            // 
            // lblCantidadA
            // 
            this.lblCantidadA.AutoSize = true;
            this.lblCantidadA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCantidadA.Location = new System.Drawing.Point(14, 240);
            this.lblCantidadA.Name = "lblCantidadA";
            this.lblCantidadA.Size = new System.Drawing.Size(86, 20);
            this.lblCantidadA.TabIndex = 9;
            this.lblCantidadA.Text = "Cantidad:";
            // 
            // lblPrecioA
            // 
            this.lblPrecioA.AutoSize = true;
            this.lblPrecioA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioA.Location = new System.Drawing.Point(14, 200);
            this.lblPrecioA.Name = "lblPrecioA";
            this.lblPrecioA.Size = new System.Drawing.Size(64, 20);
            this.lblPrecioA.TabIndex = 8;
            this.lblPrecioA.Text = "Precio:";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMarca.Location = new System.Drawing.Point(14, 320);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(63, 20);
            this.lblMarca.TabIndex = 7;
            this.lblMarca.Text = "Marca:";
            // 
            // lblNombreA
            // 
            this.lblNombreA.AutoSize = true;
            this.lblNombreA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreA.Location = new System.Drawing.Point(14, 160);
            this.lblNombreA.Name = "lblNombreA";
            this.lblNombreA.Size = new System.Drawing.Size(76, 20);
            this.lblNombreA.TabIndex = 6;
            this.lblNombreA.Text = "Nombre:";
            // 
            // txtNombreServiciosActualizacion
            // 
            this.txtNombreServiciosActualizacion.Location = new System.Drawing.Point(131, 160);
            this.txtNombreServiciosActualizacion.Name = "txtNombreServiciosActualizacion";
            this.txtNombreServiciosActualizacion.Size = new System.Drawing.Size(372, 26);
            this.txtNombreServiciosActualizacion.TabIndex = 12;
            // 
            // txtPrecioServiciosActualizacion
            // 
            this.txtPrecioServiciosActualizacion.Location = new System.Drawing.Point(131, 200);
            this.txtPrecioServiciosActualizacion.Name = "txtPrecioServiciosActualizacion";
            this.txtPrecioServiciosActualizacion.Size = new System.Drawing.Size(372, 26);
            this.txtPrecioServiciosActualizacion.TabIndex = 13;
            // 
            // txtCantidadServiciosActualizacion
            // 
            this.txtCantidadServiciosActualizacion.Location = new System.Drawing.Point(131, 240);
            this.txtCantidadServiciosActualizacion.Name = "txtCantidadServiciosActualizacion";
            this.txtCantidadServiciosActualizacion.Size = new System.Drawing.Size(372, 26);
            this.txtCantidadServiciosActualizacion.TabIndex = 15;
            // 
            // btnAceptarServiciosActualizacion
            // 
            this.btnAceptarServiciosActualizacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptarServiciosActualizacion.Location = new System.Drawing.Point(358, 400);
            this.btnAceptarServiciosActualizacion.Name = "btnAceptarServiciosActualizacion";
            this.btnAceptarServiciosActualizacion.Size = new System.Drawing.Size(145, 28);
            this.btnAceptarServiciosActualizacion.TabIndex = 18;
            this.btnAceptarServiciosActualizacion.Text = "Aceptar";
            this.btnAceptarServiciosActualizacion.UseVisualStyleBackColor = true;
            this.btnAceptarServiciosActualizacion.Click += new System.EventHandler(this.BtnActualizar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(243, 22);
            this.label1.TabIndex = 19;
            this.label1.Text = "ACTUALIZACIÓN SERVICIO";
            // 
            // CBoxProveedorServiciosActualizacion
            // 
            this.CBoxProveedorServiciosActualizacion.FormattingEnabled = true;
            this.CBoxProveedorServiciosActualizacion.Location = new System.Drawing.Point(131, 360);
            this.CBoxProveedorServiciosActualizacion.Name = "CBoxProveedorServiciosActualizacion";
            this.CBoxProveedorServiciosActualizacion.Size = new System.Drawing.Size(372, 28);
            this.CBoxProveedorServiciosActualizacion.TabIndex = 20;
            // 
            // CBoxMarcaServiciosActualizacion
            // 
            this.CBoxMarcaServiciosActualizacion.FormattingEnabled = true;
            this.CBoxMarcaServiciosActualizacion.Location = new System.Drawing.Point(131, 320);
            this.CBoxMarcaServiciosActualizacion.Name = "CBoxMarcaServiciosActualizacion";
            this.CBoxMarcaServiciosActualizacion.Size = new System.Drawing.Size(372, 28);
            this.CBoxMarcaServiciosActualizacion.TabIndex = 21;
            // 
            // CBoxTipoServiciosActualizacion
            // 
            this.CBoxTipoServiciosActualizacion.FormattingEnabled = true;
            this.CBoxTipoServiciosActualizacion.Location = new System.Drawing.Point(131, 280);
            this.CBoxTipoServiciosActualizacion.Name = "CBoxTipoServiciosActualizacion";
            this.CBoxTipoServiciosActualizacion.Size = new System.Drawing.Size(372, 28);
            this.CBoxTipoServiciosActualizacion.TabIndex = 22;
            // 
            // btnMenuPrincipalEnServiciosActualizacion
            // 
            this.btnMenuPrincipalEnServiciosActualizacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuPrincipalEnServiciosActualizacion.Location = new System.Drawing.Point(14, 400);
            this.btnMenuPrincipalEnServiciosActualizacion.Name = "btnMenuPrincipalEnServiciosActualizacion";
            this.btnMenuPrincipalEnServiciosActualizacion.Size = new System.Drawing.Size(145, 28);
            this.btnMenuPrincipalEnServiciosActualizacion.TabIndex = 23;
            this.btnMenuPrincipalEnServiciosActualizacion.Text = "Menú Principal";
            this.btnMenuPrincipalEnServiciosActualizacion.UseVisualStyleBackColor = true;
            this.btnMenuPrincipalEnServiciosActualizacion.Click += new System.EventHandler(this.BtnMenuPrincipalEnServiciosActualizacion_Click);
            // 
            // dGVActualizacionServicio
            // 
            this.dGVActualizacionServicio.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVActualizacionServicio.Location = new System.Drawing.Point(18, 454);
            this.dGVActualizacionServicio.Name = "dGVActualizacionServicio";
            this.dGVActualizacionServicio.Size = new System.Drawing.Size(485, 250);
            this.dGVActualizacionServicio.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 20);
            this.label2.TabIndex = 25;
            this.label2.Text = "Código:";
            // 
            // btnBuscarServiciosActualizacion
            // 
            this.btnBuscarServiciosActualizacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarServiciosActualizacion.Location = new System.Drawing.Point(358, 109);
            this.btnBuscarServiciosActualizacion.Name = "btnBuscarServiciosActualizacion";
            this.btnBuscarServiciosActualizacion.Size = new System.Drawing.Size(145, 28);
            this.btnBuscarServiciosActualizacion.TabIndex = 26;
            this.btnBuscarServiciosActualizacion.Text = "Buscar";
            this.btnBuscarServiciosActualizacion.UseVisualStyleBackColor = true;
            this.btnBuscarServiciosActualizacion.Click += new System.EventHandler(this.BtnBuscarServiciosActualizacion_Click);
            // 
            // TxtCodAActualizarActualizacionServicios
            // 
            this.TxtCodAActualizarActualizacionServicios.Location = new System.Drawing.Point(131, 77);
            this.TxtCodAActualizarActualizacionServicios.Name = "TxtCodAActualizarActualizacionServicios";
            this.TxtCodAActualizarActualizacionServicios.Size = new System.Drawing.Size(372, 26);
            this.TxtCodAActualizarActualizacionServicios.TabIndex = 27;
            // 
            // ServiciosActualizacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(539, 736);
            this.Controls.Add(this.TxtCodAActualizarActualizacionServicios);
            this.Controls.Add(this.btnBuscarServiciosActualizacion);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dGVActualizacionServicio);
            this.Controls.Add(this.btnMenuPrincipalEnServiciosActualizacion);
            this.Controls.Add(this.CBoxTipoServiciosActualizacion);
            this.Controls.Add(this.CBoxMarcaServiciosActualizacion);
            this.Controls.Add(this.CBoxProveedorServiciosActualizacion);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAceptarServiciosActualizacion);
            this.Controls.Add(this.txtCantidadServiciosActualizacion);
            this.Controls.Add(this.txtPrecioServiciosActualizacion);
            this.Controls.Add(this.txtNombreServiciosActualizacion);
            this.Controls.Add(this.lblProveedor);
            this.Controls.Add(this.lblTipoA);
            this.Controls.Add(this.lblCantidadA);
            this.Controls.Add(this.lblPrecioA);
            this.Controls.Add(this.lblMarca);
            this.Controls.Add(this.lblNombreA);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ServiciosActualizacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Actualización Servicio";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ServiciosActualizacion_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.dGVActualizacionServicio)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblProveedor;
        private System.Windows.Forms.Label lblTipoA;
        private System.Windows.Forms.Label lblCantidadA;
        private System.Windows.Forms.Label lblPrecioA;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.Label lblNombreA;
        private System.Windows.Forms.TextBox txtNombreServiciosActualizacion;
        private System.Windows.Forms.TextBox txtPrecioServiciosActualizacion;
        private System.Windows.Forms.TextBox txtCantidadServiciosActualizacion;
        private System.Windows.Forms.Button btnAceptarServiciosActualizacion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CBoxProveedorServiciosActualizacion;
        private System.Windows.Forms.ComboBox CBoxMarcaServiciosActualizacion;
        private System.Windows.Forms.ComboBox CBoxTipoServiciosActualizacion;
        private System.Windows.Forms.Button btnMenuPrincipalEnServiciosActualizacion;
        private System.Windows.Forms.DataGridView dGVActualizacionServicio;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBuscarServiciosActualizacion;
        private System.Windows.Forms.TextBox TxtCodAActualizarActualizacionServicios;
    }
}