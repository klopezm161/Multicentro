﻿namespace MulticentroProyectoFinal
{
    partial class ServiciosIngreso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAceptarServicioIngreso = new System.Windows.Forms.Button();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.lblCantidad = new System.Windows.Forms.Label();
            this.lblTipo = new System.Windows.Forms.Label();
            this.txtCantidadServicioIngreso = new System.Windows.Forms.TextBox();
            this.txtPrecioServicioIngreso = new System.Windows.Forms.TextBox();
            this.txtCodigoServicioIngreso = new System.Windows.Forms.TextBox();
            this.txtNombreServicioIngreso = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CBoxTipoServicioIngreso = new System.Windows.Forms.ComboBox();
            this.btnMenuPrincipalEnServicioIngreso = new System.Windows.Forms.Button();
            this.dgvServicioNuevo = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvServicioNuevo)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAceptarServicioIngreso
            // 
            this.btnAceptarServicioIngreso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptarServicioIngreso.Location = new System.Drawing.Point(358, 400);
            this.btnAceptarServicioIngreso.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAceptarServicioIngreso.Name = "btnAceptarServicioIngreso";
            this.btnAceptarServicioIngreso.Size = new System.Drawing.Size(145, 28);
            this.btnAceptarServicioIngreso.TabIndex = 7;
            this.btnAceptarServicioIngreso.Text = "Aceptar";
            this.btnAceptarServicioIngreso.UseVisualStyleBackColor = true;
            this.btnAceptarServicioIngreso.Click += new System.EventHandler(this.BtnAceptarServicioIngreso_Click);
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecio.Location = new System.Drawing.Point(14, 160);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(64, 20);
            this.lblPrecio.TabIndex = 8;
            this.lblPrecio.Text = "Precio:";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(14, 80);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(76, 20);
            this.lblNombre.TabIndex = 9;
            this.lblNombre.Text = "Nombre:";
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodigo.Location = new System.Drawing.Point(14, 120);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(70, 20);
            this.lblCodigo.TabIndex = 10;
            this.lblCodigo.Text = "Código:";
            // 
            // lblCantidad
            // 
            this.lblCantidad.AutoSize = true;
            this.lblCantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCantidad.Location = new System.Drawing.Point(14, 200);
            this.lblCantidad.Name = "lblCantidad";
            this.lblCantidad.Size = new System.Drawing.Size(86, 20);
            this.lblCantidad.TabIndex = 11;
            this.lblCantidad.Text = "Cantidad:";
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipo.Location = new System.Drawing.Point(14, 240);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(48, 20);
            this.lblTipo.TabIndex = 12;
            this.lblTipo.Text = "Tipo:";
            // 
            // txtCantidadServicioIngreso
            // 
            this.txtCantidadServicioIngreso.Location = new System.Drawing.Point(131, 200);
            this.txtCantidadServicioIngreso.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCantidadServicioIngreso.Name = "txtCantidadServicioIngreso";
            this.txtCantidadServicioIngreso.Size = new System.Drawing.Size(372, 22);
            this.txtCantidadServicioIngreso.TabIndex = 13;
            // 
            // txtPrecioServicioIngreso
            // 
            this.txtPrecioServicioIngreso.Location = new System.Drawing.Point(131, 160);
            this.txtPrecioServicioIngreso.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPrecioServicioIngreso.Name = "txtPrecioServicioIngreso";
            this.txtPrecioServicioIngreso.Size = new System.Drawing.Size(372, 22);
            this.txtPrecioServicioIngreso.TabIndex = 14;
            // 
            // txtCodigoServicioIngreso
            // 
            this.txtCodigoServicioIngreso.Location = new System.Drawing.Point(131, 120);
            this.txtCodigoServicioIngreso.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCodigoServicioIngreso.Name = "txtCodigoServicioIngreso";
            this.txtCodigoServicioIngreso.Size = new System.Drawing.Size(372, 22);
            this.txtCodigoServicioIngreso.TabIndex = 15;
            // 
            // txtNombreServicioIngreso
            // 
            this.txtNombreServicioIngreso.Location = new System.Drawing.Point(131, 80);
            this.txtNombreServicioIngreso.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNombreServicioIngreso.Name = "txtNombreServicioIngreso";
            this.txtNombreServicioIngreso.Size = new System.Drawing.Size(372, 22);
            this.txtNombreServicioIngreso.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 22);
            this.label1.TabIndex = 18;
            this.label1.Text = "SERVICIO NUEVO";
            // 
            // CBoxTipoServicioIngreso
            // 
            this.CBoxTipoServicioIngreso.FormattingEnabled = true;
            this.CBoxTipoServicioIngreso.Location = new System.Drawing.Point(131, 240);
            this.CBoxTipoServicioIngreso.Margin = new System.Windows.Forms.Padding(4);
            this.CBoxTipoServicioIngreso.Name = "CBoxTipoServicioIngreso";
            this.CBoxTipoServicioIngreso.Size = new System.Drawing.Size(372, 24);
            this.CBoxTipoServicioIngreso.TabIndex = 19;
            // 
            // btnMenuPrincipalEnServicioIngreso
            // 
            this.btnMenuPrincipalEnServicioIngreso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuPrincipalEnServicioIngreso.Location = new System.Drawing.Point(14, 400);
            this.btnMenuPrincipalEnServicioIngreso.Margin = new System.Windows.Forms.Padding(4);
            this.btnMenuPrincipalEnServicioIngreso.Name = "btnMenuPrincipalEnServicioIngreso";
            this.btnMenuPrincipalEnServicioIngreso.Size = new System.Drawing.Size(145, 28);
            this.btnMenuPrincipalEnServicioIngreso.TabIndex = 21;
            this.btnMenuPrincipalEnServicioIngreso.Text = "Menú Principal";
            this.btnMenuPrincipalEnServicioIngreso.UseVisualStyleBackColor = true;
            this.btnMenuPrincipalEnServicioIngreso.Click += new System.EventHandler(this.BtnMenuPrincipalEnServicioIngreso_Click);
            // 
            // dgvServicioNuevo
            // 
            this.dgvServicioNuevo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvServicioNuevo.Location = new System.Drawing.Point(18, 454);
            this.dgvServicioNuevo.Name = "dgvServicioNuevo";
            this.dgvServicioNuevo.Size = new System.Drawing.Size(485, 250);
            this.dgvServicioNuevo.TabIndex = 22;
            // 
            // ServiciosIngreso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(539, 736);
            this.Controls.Add(this.dgvServicioNuevo);
            this.Controls.Add(this.btnMenuPrincipalEnServicioIngreso);
            this.Controls.Add(this.CBoxTipoServicioIngreso);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNombreServicioIngreso);
            this.Controls.Add(this.txtCodigoServicioIngreso);
            this.Controls.Add(this.txtPrecioServicioIngreso);
            this.Controls.Add(this.txtCantidadServicioIngreso);
            this.Controls.Add(this.lblTipo);
            this.Controls.Add(this.lblCantidad);
            this.Controls.Add(this.lblCodigo);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.lblPrecio);
            this.Controls.Add(this.btnAceptarServicioIngreso);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ServiciosIngreso";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ingresar";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ServiciosIngreso_FormClosed);
            this.Load += new System.EventHandler(this.ServiciosIngreso_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvServicioNuevo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAceptarServicioIngreso;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.Label lblCantidad;
        private System.Windows.Forms.Label lblTipo;
        private System.Windows.Forms.TextBox txtCantidadServicioIngreso;
        private System.Windows.Forms.TextBox txtPrecioServicioIngreso;
        private System.Windows.Forms.TextBox txtCodigoServicioIngreso;
        private System.Windows.Forms.TextBox txtNombreServicioIngreso;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CBoxTipoServicioIngreso;
        private System.Windows.Forms.Button btnMenuPrincipalEnServicioIngreso;
        private System.Windows.Forms.DataGridView dgvServicioNuevo;
    }
}